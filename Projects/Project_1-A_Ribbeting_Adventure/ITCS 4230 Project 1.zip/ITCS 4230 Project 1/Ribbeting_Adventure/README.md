# Ribbeting_Adventure

Producer: DeCristo Franceschini

Programmer: Brendan Rahilly 

Designer: Jacob Welsh

Artist: Troy Vong Nguyen


Instructions: 

Click on the bugs to eat them and increase your jump height, click on platforms to grapple with your tongue. Your hype meter decreases over time, eating bugs refills it. The lower the meter, the lower your jump height. If the meter fully depletes, you lose the game. Make it to the end of the level and eat the final bug to win the game. 

Cheat Codes:

Alt + G: restarts the room

Alt + H: restarts the game

Alt + J: gives the player max hype meter

Alt + K: reduces the hype meter to 1, losing the game

Liscensing Info:

Punch 2 by Pixabay (pixabay.com)
https://pixabay.com/sound-effects/punch-2-37333/

Success Fanfare Trumpets by Pixabay (pixabay.com)
https://pixabay.com/sound-effects/success-fanfare-trumpets-6185/

Failure Drum Sound Effect 2 by Pixabay (pixabay.com)
https://pixabay.com/sound-effects/failure-drum-sound-effect-2-7184/

gameMusic by Pixabay (pixabay.com)
https://pixabay.com/sound-effects/gamemusic-6082/

Game Music Loop 7 by XtremeFreddy (pixabay.com)
https://pixabay.com/sound-effects/game-music-loop-7-145285/

Cartoon frog jump by ZapSplat (zapslat.com)
https://www.zapsplat.com/music/cartoon-frog-jump/

Cartoon frog or lizard tongue lick, slurp, eat insect 1 by ZapSplat (zapslat.com)
 https://www.zapsplat.com/music/cartoon-frog-or-lizard-tongue-lick-slurp-eat-insect-1/

Cartoon frog or lizard tongue lick, slurp, eat insect 2 by ZapSplat (zapslat.com)
https://www.zapsplat.com/music/cartoon-frog-or-lizard-tongue-lick-slurp-eat-insect-2/
